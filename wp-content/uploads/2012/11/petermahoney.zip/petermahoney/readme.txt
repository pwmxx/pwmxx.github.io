PETERMAHONEY v1.0


*************************************************
* Transparent Wordpress theme                   *
*************************************************
*                                               *
* Wordpress child theme for twentyten           *
*                                               *
* The latest version can be seen at:            *
* http://petermahoney.net                       *
*                                               *
* The latest version available for download     *
* can be downloaded at: http://petermahoney.net *
*                                               *
*************************************************


Installation notes:

Activate the "petermahoney" theme
Remove the "Header Image" entirely from /wp-admin > Appearance > Header
Upload your "Background Image" from /wp-admin > Appearance > Background
Upload your own 16x16 px favicon.ico to /wp-content/themes/petermahoney/favicon.ico
Upload your own 50x50 px logo to /wp-content/themes/petermahoney/images/header_logo.png
Edit style.css, replace "color:red" with "color:{your own colour}"


Release information:

Theme Name: petermahoney
Description: Child theme for the twentyten theme, for petermahoney.net.
Author: Peter Mahoney
Author URI: http://petermahoney.net
Version: 1.0
License: GNU General Public License v2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Template: twentyten

